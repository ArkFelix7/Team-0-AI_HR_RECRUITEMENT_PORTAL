import React, { useRef, useEffect } from 'react';
import { Candidate, Job, TranscriptEntry } from '../types';
import { useInterview } from '../hooks/useInterview';
import PhoneIcon from './icons/PhoneIcon';
import RobotIcon from './icons/RobotIcon';

interface InterviewScreenProps {
  candidate: Candidate;
  job: Job;
  onInterviewEnd: (transcript: TranscriptEntry[], emotionData: string, recording: Blob | null) => void;
}

const InterviewScreen: React.FC<InterviewScreenProps> = ({ candidate, job, onInterviewEnd }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const transcriptContainerRef = useRef<HTMLDivElement>(null);

  const {
    isConnecting,
    isLive,
    transcript,
    error,
    endInterview,
  } = useInterview({
    candidate,
    job,
    onInterviewEnd,
    videoElement: videoRef,
  });

  useEffect(() => {
    if (transcriptContainerRef.current) {
      transcriptContainerRef.current.scrollTop = transcriptContainerRef.current.scrollHeight;
    }
  }, [transcript]);

  const getStatusIndicator = () => {
    if (isConnecting) {
      return (
        <div className="flex items-center space-x-2">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-yellow-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-yellow-500"></span>
          </span>
          <span>Connecting...</span>
        </div>
      );
    }
    if (isLive) {
      return (
        <div className="flex items-center space-x-2">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
          </span>
          <span>Live</span>
        </div>
      );
    }
    return <span>Interview Ended</span>;
  };
  
  return (
    <div className="w-full h-[calc(100vh-4rem)] flex flex-col lg:flex-row gap-4">
      <div className="flex-grow lg:w-2/3 flex flex-col bg-gray-800 rounded-lg shadow-2xl border border-gray-700 overflow-hidden">
        <div className="p-4 bg-gray-900/50 border-b border-gray-700 flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">AI Interviewer</h2>
          <div className="text-sm font-medium text-gray-300">{getStatusIndicator()}</div>
        </div>
        <div ref={transcriptContainerRef} className="flex-grow p-6 space-y-4 overflow-y-auto">
          {transcript.map((entry, index) => (
            <div key={index} className={`flex items-start gap-3 ${entry.speaker === 'user' ? 'justify-end' : ''}`}>
              {entry.speaker === 'model' && <RobotIcon className="w-8 h-8 text-cyan-400 flex-shrink-0 mt-1" />}
              <div className={`max-w-xl p-3 rounded-lg ${entry.speaker === 'user' ? 'bg-cyan-600 text-white' : 'bg-gray-700'}`}>
                <p className="text-sm">{entry.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="lg:w-1/3 flex flex-col gap-4">
        <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden border-2 border-gray-700">
          <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover transform -scale-x-100"></video>
          <div className="absolute bottom-2 left-2 bg-black/50 text-white text-sm px-2 py-1 rounded">
            {candidate.name}
          </div>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 flex-grow flex flex-col justify-center items-center">
          {error && <p className="text-red-400 mb-4 text-center">{error}</p>}
          <button
            onClick={endInterview}
            disabled={!isLive}
            className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center hover:bg-red-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all transform hover:scale-110 focus:outline-none focus:ring-4 focus:ring-red-400"
          >
            <PhoneIcon className="w-10 h-10 text-white" />
          </button>
          <p className="mt-2 text-gray-400">End Interview</p>
        </div>
      </div>
    </div>
  );
};

export default InterviewScreen;