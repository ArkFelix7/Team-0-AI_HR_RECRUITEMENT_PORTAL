import React, { useState, useEffect } from 'react';
import { Analysis, TranscriptEntry } from '../types';

interface PostInterviewAnalysisProps {
  analysis: Analysis | null;
  transcript: TranscriptEntry[];
  error: string | null;
  onRestart: () => void;
  recording: Blob | null;
}

const ScoreBar: React.FC<{ score: number; label: string }> = ({ score, label }) => (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-sm font-medium text-gray-300">{label}</span>
        <span className="text-sm font-bold text-cyan-400">{score} / 100</span>
      </div>
      <div className="w-full bg-gray-700 rounded-full h-2.5">
        <div className="bg-cyan-500 h-2.5 rounded-full" style={{ width: `${score}%` }}></div>
      </div>
    </div>
  );

const PostInterviewAnalysis: React.FC<PostInterviewAnalysisProps> = ({ analysis, transcript, error, onRestart, recording }) => {
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null);

  useEffect(() => {
    if (recording) {
      const url = URL.createObjectURL(recording);
      setRecordingUrl(url);

      return () => {
        URL.revokeObjectURL(url);
        setRecordingUrl(null);
      };
    }
  }, [recording]);

  if (error) {
    return (
        <div className="bg-gray-800 rounded-lg shadow-2xl p-8 max-w-3xl mx-auto text-center border border-red-500">
            <h1 className="text-3xl font-bold text-red-400 mb-4">Analysis Failed</h1>
            <p className="text-gray-300 mb-6">{error}</p>
            <button onClick={onRestart} className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2 px-6 rounded-lg">
                Try Again
            </button>
        </div>
    );
  }
  
  if (!analysis) {
    return (
      <div className="text-center">
        <div role="status">
            <svg aria-hidden="true" className="inline w-12 h-12 text-gray-600 animate-spin fill-cyan-500" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
                <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0492C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentFill"/>
            </svg>
            <span className="sr-only">Loading...</span>
        </div>
        <p className="mt-4 text-lg text-gray-300">Analyzing interview performance...</p>
      </div>
    );
  }

  return (
    <div className="bg-gray-800 rounded-lg shadow-2xl p-8 max-w-4xl mx-auto border border-gray-700">
      <h1 className="text-3xl font-bold text-white mb-2">Interview Analysis</h1>
      <p className="text-gray-300 mb-6">{analysis.overallImpression}</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        <div className="bg-gray-900/50 p-6 rounded-lg border border-gray-700">
            <h2 className="text-xl font-semibold text-cyan-400 mb-4">Performance Scorecard</h2>
            <div className="space-y-4">
                <ScoreBar score={analysis.knowledge.score} label="Knowledge" />
                <ScoreBar score={analysis.communicationSkills.score} label="Communication Skills" />
                <ScoreBar score={analysis.confidence.score} label="Confidence" />
                <ScoreBar score={analysis.expressiveness.score} label="Expressiveness" />
            </div>
        </div>

        <div className="flex flex-col gap-6">
            <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                <h3 className="font-semibold text-purple-400 mb-2">Emotional Tone Analysis</h3>
                <p className="text-sm text-gray-300"><span className="font-semibold text-gray-400">Dominant Emotion:</span> {analysis.emotionAnalysis.dominantEmotion}</p>
                <p className="text-sm text-gray-300 mt-1">{analysis.emotionAnalysis.summary}</p>
            </div>
            <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                <h3 className="font-semibold text-green-400 mb-2">Strengths</h3>
                <ul className="list-disc list-inside text-gray-300 space-y-1 text-sm">
                    {analysis.strengths.map((s, i) => <li key={i}>{s}</li>)}
                </ul>
            </div>
            <div className="bg-gray-900/50 p-4 rounded-lg border border-gray-700">
                <h3 className="font-semibold text-yellow-400 mb-2">Areas for Improvement</h3>
                <ul className="list-disc list-inside text-gray-300 space-y-1 text-sm">
                    {analysis.areasForImprovement.map((a, i) => <li key={i}>{a}</li>)}
                </ul>
            </div>
        </div>
      </div>
      
      <div className="text-center mt-6 flex justify-center items-center gap-4">
        {recordingUrl && (
            <a
                href={recordingUrl}
                download={`interview-recording-${new Date().toISOString()}.webm`}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition-colors"
            >
                Download Recording
            </a>
        )}
        <button onClick={onRestart} className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-2 px-6 rounded-lg transition-colors">
            New Interview
        </button>
      </div>
    </div>
  );
};

export default PostInterviewAnalysis;