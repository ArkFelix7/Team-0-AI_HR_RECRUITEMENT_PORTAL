import React from 'react';
import { Candidate, Job } from '../types';
import RobotIcon from './icons/RobotIcon';
import MicIcon from './icons/MicIcon';
import VideoIcon from './icons/VideoIcon';

interface PreInterviewScreenProps {
  candidate: Candidate;
  job: Job;
  onStart: () => void;
}

const PreInterviewScreen: React.FC<PreInterviewScreenProps> = ({ candidate, job, onStart }) => {
  return (
    <div className="bg-gray-800 rounded-lg shadow-2xl p-8 max-w-3xl mx-auto text-center border border-gray-700">
      <div className="flex justify-center mb-6">
        <RobotIcon className="w-20 h-20 text-cyan-400" />
      </div>
      <h1 className="text-4xl font-bold text-white mb-2">Technical Interview</h1>
      <p className="text-lg text-gray-300 mb-4">You are interviewing for the specified role.</p>
      
      <div className="bg-gray-900/50 rounded-lg p-6 my-8 text-left space-y-4 border border-gray-700">
        <h2 className="text-2xl font-semibold text-cyan-400">Welcome, {candidate.name}</h2>
        <p className="text-gray-300">
          This is an automated technical screening conducted by our AI interviewer. The interview will be based on your resume and the requirements for the role.
        </p>
        <p className="text-gray-300">
          Please ensure you are in a quiet environment with a stable internet connection.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-8 text-left">
        <div className="bg-gray-700/50 rounded-lg p-4 flex items-center space-x-4">
          <MicIcon className="w-8 h-8 text-green-400 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-white">Audio & Video Recording</h3>
            <p className="text-sm text-gray-400">The session will be recorded for analysis.</p>
          </div>
        </div>
        <div className="bg-gray-700/50 rounded-lg p-4 flex items-center space-x-4">
          <VideoIcon className="w-8 h-8 text-green-400 flex-shrink-0" />
          <div>
            <h3 className="font-semibold text-white">Camera & Microphone</h3>
            <p className="text-sm text-gray-400">We will need access to your devices.</p>
          </div>
        </div>
      </div>

      <button
        onClick={onStart}
        className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-4 px-8 rounded-lg text-xl transition-transform transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-cyan-300"
      >
        Begin Interview
      </button>
    </div>
  );
};

export default PreInterviewScreen;