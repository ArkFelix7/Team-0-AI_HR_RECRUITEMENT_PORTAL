import React, { useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import { Candidate, Job } from '../types';
import { extractResumeHighlights } from '../services/geminiService';
import RobotIcon from './icons/RobotIcon';
import UploadIcon from './icons/UploadIcon';

// Configure the PDF.js worker source
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.worker.min.mjs`;

interface SetupScreenProps {
  onSetupComplete: (job: Job, candidate: Candidate) => void;
}

const SetupScreen: React.FC<SetupScreenProps> = ({ onSetupComplete }) => {
  const [jobDescription, setJobDescription] = useState('');
  const [candidateName, setCandidateName] = useState('');
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      if (file.type === 'application/pdf') {
        setResumeFile(file);
        setError(null);
      } else {
        setError('Please upload a .pdf file for the resume.');
        setResumeFile(null);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobDescription || !candidateName || !resumeFile) {
      setError('All fields are required.');
      return;
    }
    setError(null);
    setIsLoading(true);

    try {
      const arrayBuffer = await resumeFile.arrayBuffer();
      const pdfDoc = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let resumeText = "";

      for (let i = 1; i <= pdfDoc.numPages; i++) {
        const page = await pdfDoc.getPage(i);
        const textContent = await page.getTextContent();
        // Using 'any' as TextItem type is not available without full TS setup
        const pageText = textContent.items.map((item: any) => item.str).join(" ");
        resumeText += pageText + "\n";
      }

      if (!resumeText.trim()) {
        throw new Error("Could not extract text from PDF. The file might be empty, corrupted, or contain only images.");
      }
      
      const resumeHighlights = await extractResumeHighlights(resumeText);
      
      const job: Job = { description: jobDescription };
      const candidate: Candidate = { name: candidateName, resumeHighlights };

      onSetupComplete(job, candidate);

    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : 'An unknown error occurred during setup.');
    } finally {
      setIsLoading(false);
    }
  };

  const isFormValid = jobDescription && candidateName && resumeFile;

  return (
    <div className="bg-gray-800 rounded-lg shadow-2xl p-8 max-w-3xl mx-auto border border-gray-700">
        <div className="flex justify-center mb-6">
            <RobotIcon className="w-20 h-20 text-cyan-400" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-2 text-center">AI Interview Setup</h1>
        <p className="text-lg text-gray-300 mb-8 text-center">
            Provide the job and candidate details to begin.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
            <div>
                <label htmlFor="job-description" className="block text-sm font-medium text-gray-300 mb-2">
                    Job Description
                </label>
                <textarea
                    id="job-description"
                    rows={6}
                    className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 text-white focus:ring-cyan-500 focus:border-cyan-500 transition"
                    placeholder="Paste the full job description here..."
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    required
                />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="candidate-name" className="block text-sm font-medium text-gray-300 mb-2">
                        Candidate Name
                    </label>
                    <input
                        type="text"
                        id="candidate-name"
                        className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 text-white focus:ring-cyan-500 focus:border-cyan-500 transition"
                        placeholder="e.g., Jane Doe"
                        value={candidateName}
                        onChange={(e) => setCandidateName(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="resume-file" className="block text-sm font-medium text-gray-300 mb-2">
                        Candidate Resume (.pdf)
                    </label>
                    <label htmlFor="resume-file" className="w-full bg-gray-900 border border-gray-600 rounded-md p-3 text-white flex items-center justify-center cursor-pointer hover:border-cyan-500 transition">
                        <UploadIcon className="w-6 h-6 mr-2 text-gray-400" />
                        <span className="text-gray-400 truncate">{resumeFile ? resumeFile.name : 'Upload .pdf file'}</span>
                    </label>
                    <input
                        type="file"
                        id="resume-file"
                        className="hidden"
                        accept=".pdf,application/pdf"
                        onChange={handleFileChange}
                        required
                    />
                </div>
            </div>

            {error && <p className="text-red-400 text-sm text-center">{error}</p>}
            
            <button
                type="submit"
                disabled={!isFormValid || isLoading}
                className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-4 px-8 rounded-lg text-xl transition-transform transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-cyan-300 disabled:bg-gray-600 disabled:cursor-not-allowed disabled:scale-100 flex items-center justify-center"
            >
                {isLoading && (
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                )}
                {isLoading ? 'Analyzing Resume...' : 'Start Interview'}
            </button>
        </form>
    </div>
  );
};

export default SetupScreen;