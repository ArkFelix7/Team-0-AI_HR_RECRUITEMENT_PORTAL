
// Fix: Import React to resolve "Cannot find namespace 'React'" error.
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Candidate, Job, TranscriptEntry } from '../types';
// Fix: Remove `LiveSession` from import as it is not an exported member of '@google/genai'.
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';

declare const faceapi: any;

interface UseInterviewProps {
  candidate: Candidate;
  job: Job;
  onInterviewEnd: (transcript: TranscriptEntry[], emotionData: string, recording: Blob | null) => void;
  videoElement: React.RefObject<HTMLVideoElement>;
}

// Fix: Add a local interface for `LiveSession` as it is not exported from the library.
interface LiveSession {
  close: () => void;
  sendRealtimeInput: (input: { media: { data: string; mimeType: string } }) => void;
}

// Helper functions for audio encoding/decoding
const encode = (bytes: Uint8Array): string => {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
};

const decode = (base64: string): Uint8Array => {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
};

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length;
  // The AI audio output is single-channel (mono) at 24kHz
  const buffer = ctx.createBuffer(1, frameCount, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < frameCount; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
}

export const useInterview = ({ candidate, job, onInterviewEnd, videoElement }: UseInterviewProps) => {
  const [isConnecting, setIsConnecting] = useState(true);
  const [isLive, setIsLive] = useState(false);
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([
    { speaker: 'model', text: `Hello, ${candidate.name}. I'm connecting now. The interview will begin shortly.` }
  ]);
  const [error, setError] = useState<string | null>(null);

  // Ref to track live status to avoid stale closures in setInterval
  const isLiveRef = useRef(isLive);
  useEffect(() => {
    isLiveRef.current = isLive;
  }, [isLive]);

  const sessionRef = useRef<LiveSession | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  
  const mixingContextRef = useRef<AudioContext | null>(null);
  const recordingDestinationNodeRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const hasEndedRef = useRef(false);

  const finalTranscriptRef = useRef<TranscriptEntry[]>([]);

  const emotionHistoryRef = useRef<any[]>([]);
  const faceApiIntervalRef = useRef<number | null>(null);
  const modelsLoaded = useRef(false);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    finalTranscriptRef.current = transcript;
  }, [transcript]);

  const stopFaceApi = () => {
    if (faceApiIntervalRef.current) {
        clearInterval(faceApiIntervalRef.current);
        faceApiIntervalRef.current = null;
    }
  };

  const processEmotionData = (): string => {
    if (emotionHistoryRef.current.length === 0) {
      return "No facial expression data was collected.";
    }

    const emotionCounts: Record<string, number> = {};
    let validDetections = 0;

    emotionHistoryRef.current.forEach(detection => {
      if (detection && detection.expressions) {
        const expressions = detection.expressions;
        let dominantEmotion: string | null = null;
        let maxScore = 0;

        // Find the dominant emotion for this specific detection frame
        for (const [emotion, score] of Object.entries(expressions)) {
          if ((score as number) > maxScore) {
            maxScore = score as number;
            dominantEmotion = emotion;
          }
        }
        
        // Only count if the detection is reasonably confident (e.g., > 50%)
        if (dominantEmotion && maxScore > 0.5) {
          validDetections++;
          emotionCounts[dominantEmotion] = (emotionCounts[dominantEmotion] || 0) + 1;
        }
      }
    });

    if (validDetections === 0) {
      return "Could not confidently detect distinct facial expressions. This may be due to lighting, camera angle, or a consistently neutral expression.";
    }

    // Find the most frequent dominant emotion over the whole interview
    const overallDominantEmotion = Object.keys(emotionCounts).reduce((a, b) => emotionCounts[a] > emotionCounts[b] ? a : b);
    
    const percentages = Object.entries(emotionCounts)
      .sort(([, a], [, b]) => b - a)
      .map(([emotion, count]) => {
        const capitalized = emotion.charAt(0).toUpperCase() + emotion.slice(1);
        return `${capitalized} (${((count / validDetections) * 100).toFixed(0)}%)`;
      }).join(', ');
    
    const capitalizedDominant = overallDominantEmotion.charAt(0).toUpperCase() + overallDominantEmotion.slice(1);
    
    return `The dominant emotion detected was '${capitalizedDominant}'. A breakdown of observed expressions includes: ${percentages}.`;
  };


  const stopStreaming = useCallback(() => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
    }
    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
    }
    if(mediaStreamSourceRef.current){
        mediaStreamSourceRef.current.disconnect();
    }
    if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
      inputAudioContextRef.current.close();
    }
    if (mixingContextRef.current && mixingContextRef.current.state !== 'closed') {
        for (const source of audioSourcesRef.current.values()) {
            try {
              source.stop();
            } catch (e) {
              // Ignore errors if source is already stopped
            }
        }
        audioSourcesRef.current.clear();
        mixingContextRef.current.close();
    }
  }, []);

  const endInterview = useCallback(() => {
    if (hasEndedRef.current) return;
    hasEndedRef.current = true;
    
    stopFaceApi();
    setIsLive(false);
    setIsConnecting(false);

    if (sessionRef.current) {
        sessionRef.current.close();
        sessionRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
        mediaRecorderRef.current.addEventListener('stop', () => {
            const recordingBlob = new Blob(recordedChunksRef.current, { type: 'video/webm' });
            const emotionSummary = processEmotionData();
            onInterviewEnd(finalTranscriptRef.current, emotionSummary, recordingBlob);
            stopStreaming();
        }, { once: true });
        mediaRecorderRef.current.stop();
    } else {
        const emotionSummary = processEmotionData();
        onInterviewEnd(finalTranscriptRef.current, emotionSummary, null);
        stopStreaming();
    }
  }, [onInterviewEnd, stopStreaming]);

  const startInterview = useCallback(async () => {
    setIsConnecting(true);
    setError(null);
    setTranscript(prev => prev.slice(0, 1));

    if (!process.env.API_KEY) {
      setError("API_KEY environment variable not set");
      setIsConnecting(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      mediaStreamRef.current = stream;

      // This context is for mixing user audio + AI audio for recording and playback.
      // We use 24kHz because that's the sample rate of the AI's audio output.
      mixingContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const mixingContext = mixingContextRef.current;
      
      // Create a destination node. The stream from this node will contain the mixed audio.
      recordingDestinationNodeRef.current = mixingContext.createMediaStreamDestination();
      const recordingDestinationNode = recordingDestinationNodeRef.current;

      // Connect the user's microphone to the mixing context and route it to the recording destination.
      // DO NOT connect this to the main mixingContext.destination, to avoid the user hearing themselves.
      const userMicSource = mixingContext.createMediaStreamSource(stream);
      userMicSource.connect(recordingDestinationNode);

      // Create the final stream for the MediaRecorder: user's video + mixed audio.
      const combinedStream = new MediaStream([
        ...stream.getVideoTracks(),
        ...recordingDestinationNode.stream.getAudioTracks()
      ]);

      if (videoElement.current) {
        const videoEl = videoElement.current;
        videoEl.srcObject = stream; // Display the original user stream, not the combined one.
        
        const startFaceDetection = async () => {
          try {
            if (!modelsLoaded.current) {
              const MODEL_URL = 'https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@0.22.2/weights';
              await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
              await faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL);
              modelsLoaded.current = true;
            }
      
            if (faceApiIntervalRef.current) clearInterval(faceApiIntervalRef.current);
            
            faceApiIntervalRef.current = window.setInterval(async () => {
              if (videoEl && !videoEl.paused && isLiveRef.current) {
                const detections = await faceapi.detectSingleFace(videoEl, new faceapi.TinyFaceDetectorOptions()).withFaceExpressions();
                if ( detections) {
                  emotionHistoryRef.current.push(detections);
                }
              }
            }, 1500);
          } catch (e) {
            console.error("Failed to initialize face detection:", e);
          }
        };
        videoEl.addEventListener('playing', startFaceDetection);
      }

      mediaRecorderRef.current = new MediaRecorder(combinedStream, { mimeType: 'video/webm;codecs=vp9,opus' });
      recordedChunksRef.current = [];
      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          recordedChunksRef.current.push(event.data);
        }
      };
      mediaRecorderRef.current.start();
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

      const systemInstruction = `You are Alex, an expert AI technical interviewer. You're conducting a screening interview with ${candidate.name} for a role with the following description:
      ---
      ${job.description}
      ---
      You have their resume highlights in front of you: ${candidate.resumeHighlights.join('; ')}.
      Your goal is to have a natural, 5-minute technical conversation.

      **CRITICAL RULE: NEVER interrupt the candidate. Wait for them to finish speaking completely, and allow for a natural pause (1-2 seconds of silence) before you begin your response. This is the most important rule to follow.**

      **Your first task is to start the conversation.**
      1. Greet ${candidate.name} warmly.
      2. Introduce yourself as Alex.
      3. Mention you've reviewed their resume and are impressed by one of their projects or skills.
      4. Ask an open-ended ice-breaker question about that project/skill to get things started.

      After the ice-breaker, ask 3-4 technical questions relevant to the job description and their resume.
      Listen to their full answers before you speak. Be encouraging and professional.
      To end the interview, thank them for their time and explain that the hiring team will be in touch with the next steps.
      Speak clearly and with a friendly tone. Begin the interview now.`;
      
      let currentInputTranscription = '';
      let currentOutputTranscription = '';

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
          systemInstruction,
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
        },
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsLive(true);
            setTranscript([]);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.inputTranscription) {
              const textChunk = message.serverContent.inputTranscription.text;
              currentInputTranscription += textChunk;
              
              setTranscript(prev => {
                  const lastEntry = prev.length > 0 ? prev[prev.length - 1] : null;
                  if (lastEntry && lastEntry.speaker === 'user') {
                      const updatedEntry = { ...lastEntry, text: currentInputTranscription };
                      return [...prev.slice(0, -1), updatedEntry];
                  } else {
                     return [...prev, { speaker: 'user', text: currentInputTranscription }];
                  }
              });
            }

            if (message.serverContent?.outputTranscription) {
                const textChunk = message.serverContent.outputTranscription.text;
                currentOutputTranscription += textChunk;

                setTranscript(prev => {
                    const lastEntry = prev.length > 0 ? prev[prev.length - 1] : null;
                    if (lastEntry && lastEntry.speaker === 'model') {
                        const updatedEntry = { ...lastEntry, text: currentOutputTranscription };
                        return [...prev.slice(0, -1), updatedEntry];
                    } else {
                       return [...prev, { speaker: 'model', text: currentOutputTranscription }];
                    }
                });
            }

            if (message.serverContent?.turnComplete) {
                currentInputTranscription = '';
                currentOutputTranscription = '';
            }

            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData.data;
            if (audioData && mixingContextRef.current && recordingDestinationNodeRef.current) {
              const audioContext = mixingContextRef.current;
              const recordingDest = recordingDestinationNodeRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, audioContext.currentTime);
              
              const audioBuffer = await decodeAudioData(decode(audioData), audioContext);
              const source = audioContext.createBufferSource();
              source.buffer = audioBuffer;
              
              // Connect to the main destination so the user can hear the AI.
              source.connect(audioContext.destination);
              // Also connect to the recording destination so it gets recorded.
              source.connect(recordingDest);

              source.addEventListener('ended', () => {
                audioSourcesRef.current.delete(source);
              });
              
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              audioSourcesRef.current.add(source);
            }
            
            const interrupted = message.serverContent?.interrupted;
            if (interrupted) {
                for (const source of audioSourcesRef.current.values()) {
                    source.stop();
                    audioSourcesRef.current.delete(source);
                }
                nextStartTimeRef.current = 0;
            }
          },
          onclose: () => {
            endInterview();
          },
          onerror: (e: ErrorEvent) => {
            console.error(e);
            setError('A connection error occurred.');
            endInterview();
          },
        },
      });

      sessionRef.current = await sessionPromise;
      
      // This separate context is for processing user audio to send to Gemini.
      // It needs to be 16kHz as required by the API.
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const inputAudioContext = inputAudioContextRef.current;
      mediaStreamSourceRef.current = inputAudioContext.createMediaStreamSource(stream);
      scriptProcessorRef.current = inputAudioContext.createScriptProcessor(4096, 1, 1);

      scriptProcessorRef.current.onaudioprocess = (event: AudioProcessingEvent) => {
        const inputData = event.inputBuffer.getChannelData(0);
        const l = inputData.length;
        const int16 = new Int16Array(l);
        for (let i = 0; i < l; i++) {
            int16[i] = inputData[i] * 32768;
        }
        const pcmBlob = {
            data: encode(new Uint8Array(int16.buffer)),
            mimeType: 'audio/pcm;rate=16000',
        };
        sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
      };
      mediaStreamSourceRef.current.connect(scriptProcessorRef.current);
      scriptProcessorRef.current.connect(inputAudioContext.destination);


    } catch (err) {
      console.error(err);
      setError('Failed to start interview. Check permissions and connection.');
      setIsConnecting(false);
      stopStreaming();
    }
  }, [candidate, job, stopStreaming, endInterview, videoElement]);

  useEffect(() => {
    startInterview();
    return () => {
      if (!hasEndedRef.current) {
        endInterview();
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { isConnecting, isLive, transcript, error, endInterview };
};
