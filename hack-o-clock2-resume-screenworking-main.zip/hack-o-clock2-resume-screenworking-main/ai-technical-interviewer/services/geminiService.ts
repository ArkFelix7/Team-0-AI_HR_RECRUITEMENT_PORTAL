import { GoogleGenAI, Type } from '@google/genai';
import { TranscriptEntry, Candidate, Job, Analysis } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const resumeHighlightsSchema = {
    type: Type.ARRAY,
    items: { type: Type.STRING },
    description: "A list of key highlights from the resume."
};

export const extractResumeHighlights = async (resumeText: string): Promise<string[]> => {
    const prompt = `
        Based on the following resume text, extract up to 5 key highlights that are most relevant for a technical interview. 
        Focus on skills, technologies, and significant project achievements. 
        Your output MUST be a JSON object that conforms to the provided schema.

        Resume Text:
        ---
        ${resumeText}
        ---
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        highlights: resumeHighlightsSchema,
                    },
                    required: ['highlights']
                },
            },
        });
        
        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);
        
        return parsedJson.highlights as string[];
    } catch (error) {
        console.error("Error extracting resume highlights with Gemini:", error);
        throw new Error("Failed to get a valid analysis from the AI model.");
    }
}

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        overallImpression: { type: Type.STRING, description: "A brief, overall summary of the candidate's performance." },
        confidence: {
            type: Type.OBJECT,
            properties: {
                score: { type: Type.INTEGER, description: "Score from 0 to 100 on the candidate's confidence." },
                reasoning: { type: Type.STRING, description: "Detailed reasoning for the confidence score." }
            },
            required: ['score', 'reasoning']
        },
        expressiveness: {
            type: Type.OBJECT,
            properties: {
                score: { type: Type.INTEGER, description: "Score from 0 to 100 on the candidate's expressiveness and articulation." },
                reasoning: { type: Type.STRING, description: "Detailed reasoning for the expressiveness score." }
            },
            required: ['score', 'reasoning']
        },
        knowledge: {
            type: Type.OBJECT,
            properties: {
                score: { type: Type.INTEGER, description: "Score from 0 to 100 on the candidate's technical knowledge relevant to the job." },
                reasoning: { type: Type.STRING, description: "Detailed reasoning for the knowledge score, with examples from the transcript." }
            },
            required: ['score', 'reasoning']
        },
        communicationSkills: {
            type: Type.OBJECT,
            properties: {
                score: { type: Type.INTEGER, description: "Score from 0 to 100 on the candidate's overall communication skills." },
                reasoning: { type: Type.STRING, description: "Detailed reasoning for the communication skills score." }
            },
            required: ['score', 'reasoning']
        },
        strengths: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of the candidate's key strengths observed during the interview."
        },
        areasForImprovement: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of areas where the candidate could improve."
        },
        emotionAnalysis: {
            type: Type.OBJECT,
            properties: {
                summary: { type: Type.STRING, description: "A brief summary of the candidate's emotional state based on facial expressions, noting any changes." },
                dominantEmotion: { type: Type.STRING, description: "The most frequently observed emotion during the interview (e.g., 'Neutral', 'Happy', 'Anxious')." }
            },
            required: ['summary', 'dominantEmotion']
        }
    },
    required: [
        'overallImpression', 'confidence', 'expressiveness',
        'knowledge', 'communicationSkills', 'strengths', 'areasForImprovement', 'emotionAnalysis'
    ]
};

export const analyzeTranscript = async (
    transcript: TranscriptEntry[],
    candidate: Candidate,
    job: Job,
    emotionData: string
): Promise<Analysis> => {
    const formattedTranscript = transcript
        .map(entry => `${entry.speaker === 'user' ? 'Candidate' : 'Interviewer'}: ${entry.text}`)
        .join('\n');

    const prompt = `
        You are an expert hiring manager analyzing a technical interview transcript for a role with this description:
        ---
        ${job.description}
        ---
        The candidate is ${candidate.name}. Their resume highlights include: ${candidate.resumeHighlights.join(', ')}.

        Instructions:
        Analyze the following interview transcript and provide a detailed evaluation based on the candidate's performance relative to the job role.
        In addition to the transcript, you are provided with an analysis of the candidate's facial expressions. Use this emotional context to refine your assessment of Confidence and Expressiveness. For example, a candidate who looks nervous but answers correctly might be highly competent but anxious. A candidate who looks confident but gives vague answers may be overcompensating.
        Your output MUST be a JSON object that conforms to the provided schema.

        Evaluation Criteria (Score each from 0 to 100):
        - Confidence: How self-assured and composed did the candidate appear? Consider both their words and their observed emotional state.
        - Expressiveness: How well did the candidate articulate their thoughts? Did their facial expressions align with their words and convey engagement?
        - Knowledge: Assess the depth and accuracy of the candidate's technical knowledge based on their answers. How well does their knowledge align with the requirements for a the job?
        - Communication Skills: Evaluate the candidate's overall ability to communicate. Did they listen to questions, structure their answers logically, and convey information effectively?

        Interview Transcript:
        ---
        ${formattedTranscript}
        ---

        Summary of Facial Expression Analysis:
        ---
        ${emotionData}
        ---
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: analysisSchema,
            },
        });
        
        const jsonText = response.text.trim();
        const parsedJson = JSON.parse(jsonText);

        return parsedJson as Analysis;

    } catch (error) {
        console.error("Error analyzing transcript with Gemini:", error);
        throw new Error("Failed to get a valid analysis from the AI model.");
    }
};