
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveSession } from '@google/genai';
import { CallState, TranscriptEntry, Speaker, CallAnalysis } from './types';
import { startLiveSession, getPostCallAnalysis } from './services/geminiService';
import { PhoneIcon, MicIcon, BrainIcon, DocumentTextIcon, DownloadIcon } from './components/Icons';

// --- Audio Utility Helpers ---
function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}


const App: React.FC = () => {
    const [callState, setCallState] = useState<CallState>(CallState.IDLE);
    const [transcript, setTranscript] = useState<TranscriptEntry[]>([]);
    const [analysis, setAnalysis] = useState<CallAnalysis | null>(null);
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [recordedAudioUrl, setRecordedAudioUrl] = useState<string | null>(null);

    const sessionRef = useRef<LiveSession | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const userSourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const nextStartTimeRef = useRef<number>(0);
    const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<globalThis.Blob[]>([]);
    const recorderDestinationRef = useRef<MediaStreamAudioDestinationNode | null>(null);


    const updateTranscript = useCallback((newEntry: TranscriptEntry) => {
        setTranscript(prev => {
            if (!newEntry.text?.trim()) {
                return prev;
            }

            const lastEntry = prev.length > 0 ? prev[prev.length - 1] : null;

            if (lastEntry && lastEntry.speaker === newEntry.speaker && !lastEntry.isFinal) {
                const newText = newEntry.isFinal ? newEntry.text : lastEntry.text + newEntry.text;
                
                const updatedEntry = { 
                  ...lastEntry, 
                  text: newText, 
                  isFinal: newEntry.isFinal 
                };
                
                return [...prev.slice(0, -1), updatedEntry];
            } else {
                return [...prev, newEntry];
            }
        });
    }, []);

    const handleAudioPlayback = useCallback(async (base64Audio: string) => {
        if (!outputAudioContextRef.current) return;
        const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContextRef.current, 24000, 1);
        
        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContextRef.current.currentTime);
        
        const source = outputAudioContextRef.current.createBufferSource();
        source.buffer = audioBuffer;
        
        source.connect(outputAudioContextRef.current.destination);

        if (recorderDestinationRef.current) {
            source.connect(recorderDestinationRef.current);
        }

        source.addEventListener('ended', () => {
            audioSourcesRef.current.delete(source);
        });
        source.start(nextStartTimeRef.current);
        nextStartTimeRef.current += audioBuffer.duration;
        audioSourcesRef.current.add(source);
    }, []);

    const startCall = async () => {
        setCallState(CallState.CONNECTING);
        setErrorMessage('');
        setTranscript([]);
        setAnalysis(null);
        if (recordedAudioUrl) {
          URL.revokeObjectURL(recordedAudioUrl);
        }
        setRecordedAudioUrl(null);


        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;

            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            const outputContext = outputAudioContextRef.current;
            
            // --- Setup Recording ---
            recorderDestinationRef.current = outputContext.createMediaStreamDestination();

            const userSource = outputContext.createMediaStreamSource(stream);
            userSourceNodeRef.current = userSource;
            userSource.connect(recorderDestinationRef.current);

            mediaRecorderRef.current = new MediaRecorder(recorderDestinationRef.current.stream);
            mediaRecorderRef.current.ondataavailable = (event) => {
              if (event.data.size > 0) audioChunksRef.current.push(event.data);
            };
            mediaRecorderRef.current.onstop = () => {
              const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
              const url = URL.createObjectURL(audioBlob);
              setRecordedAudioUrl(url);
              audioChunksRef.current = [];
            };
            mediaRecorderRef.current.start();
            // --- End Setup Recording ---


            const sessionPromise = startLiveSession(
              updateTranscript,
              handleAudioPlayback,
              (err) => {
                setErrorMessage(err);
                setCallState(CallState.ERROR);
              }
            );
            
            sessionPromise.then(session => {
              sessionRef.current = session;
              setCallState(CallState.ACTIVE);
            }).catch(e => {
              console.error("Failed to start session", e);
              setErrorMessage("Could not connect to the AI. Please check your API key and permissions.");
              setCallState(CallState.ERROR);
            });
            
            const source = inputAudioContextRef.current.createMediaStreamSource(stream);
            mediaStreamSourceRef.current = source;
            const scriptProcessor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            scriptProcessorRef.current = scriptProcessor;

            scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                const l = inputData.length;
                const int16 = new Int16Array(l);
                for (let i = 0; i < l; i++) {
                    int16[i] = inputData[i] * 32768;
                }
                const pcmBlob = {
                    data: encode(new Uint8Array(int16.buffer)),
                    mimeType: 'audio/pcm;rate=16000',
                };
                sessionPromise.then((session) => {
                    session.sendRealtimeInput({ media: pcmBlob });
                });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(inputAudioContextRef.current.destination);
            
        } catch (error) {
            console.error('Error starting call:', error);
            setErrorMessage('Microphone access denied. Please allow microphone permissions in your browser settings.');
            setCallState(CallState.ERROR);
        }
    };
    
    const stopCall = useCallback(async () => {
        mediaRecorderRef.current?.stop();
        setCallState(CallState.ANALYZING);

        sessionRef.current?.close();
        
        mediaStreamRef.current?.getTracks().forEach(track => track.stop());
        scriptProcessorRef.current?.disconnect();
        mediaStreamSourceRef.current?.disconnect();
        userSourceNodeRef.current?.disconnect();
        inputAudioContextRef.current?.close();
        outputAudioContextRef.current?.close();

        sessionRef.current = null;
        mediaStreamRef.current = null;
        inputAudioContextRef.current = null;
        outputAudioContextRef.current = null;
        scriptProcessorRef.current = null;
        mediaStreamSourceRef.current = null;
        userSourceNodeRef.current = null;
        nextStartTimeRef.current = 0;
        audioSourcesRef.current.clear();
        mediaRecorderRef.current = null;
        recorderDestinationRef.current = null;
        
        const finalTranscript = transcript.map(t => ({...t, isFinal: true}));
        const analysisResult = await getPostCallAnalysis(finalTranscript);
        setAnalysis(analysisResult);
        setCallState(CallState.ENDED);
    }, [transcript]);

    const reset = () => {
      if (recordedAudioUrl) {
          URL.revokeObjectURL(recordedAudioUrl);
      }
      setRecordedAudioUrl(null);
      setCallState(CallState.IDLE);
      setTranscript([]);
      setAnalysis(null);
      setErrorMessage('');
    }

    return (
        <div className="min-h-screen bg-gray-900 flex flex-col items-center justify-center p-4 font-sans">
            <div className="w-full max-w-2xl mx-auto bg-gray-800 rounded-2xl shadow-2xl flex flex-col min-h-[70vh]">
                <Header />
                <main className="flex-grow p-6 flex flex-col">
                    {callState === CallState.IDLE && <StartScreen onStart={startCall} />}
                    {callState === CallState.ERROR && <ErrorScreen message={errorMessage} onRetry={reset} />}
                    {callState === CallState.CONNECTING && <StatusScreen message="Connecting Call..." />}
                    {callState === CallState.ACTIVE && <CallScreen transcript={transcript} onStop={stopCall} />}
                    {callState === CallState.ANALYZING && <StatusScreen message="Analyzing Call..." />}
                    {callState === CallState.ENDED && <ResultsScreen analysis={analysis} transcript={transcript} onReset={reset} recordedAudioUrl={recordedAudioUrl}/>}
                </main>
            </div>
        </div>
    );
};


const Header: React.FC = () => (
    <header className="border-b border-gray-700 p-4 text-center">
        <h1 className="text-2xl font-bold text-cyan-400">Gemini AI Interview Scheduler</h1>
        <p className="text-gray-400 text-sm">Automated Voice Calls for Interview Scheduling</p>
    </header>
);

const StartScreen: React.FC<{ onStart: () => void }> = ({ onStart }) => (
    <div className="flex flex-col items-center justify-center h-full text-center">
        <PhoneIcon className="w-24 h-24 text-gray-500 mb-6" />
        <h2 className="text-xl font-semibold mb-4">Ready to start the automated call?</h2>
        <p className="text-gray-400 mb-8 max-w-sm">
            The AI will initiate a voice call to a simulated candidate to schedule their technical interview.
        </p>
        <button onClick={onStart} className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-8 rounded-full transition-transform transform hover:scale-105 shadow-lg">
            Start Call
        </button>
    </div>
);

const ErrorScreen: React.FC<{ message: string; onRetry: () => void }> = ({ message, onRetry }) => (
     <div className="flex flex-col items-center justify-center h-full text-center">
        <h2 className="text-xl font-semibold text-red-500 mb-4">An Error Occurred</h2>
        <p className="text-gray-300 mb-8 max-w-sm">{message}</p>
        <button onClick={onRetry} className="bg-gray-600 hover:bg-gray-700 text-white font-bold py-3 px-8 rounded-full transition-colors">
            Try Again
        </button>
    </div>
)

const StatusScreen: React.FC<{ message: string }> = ({ message }) => (
    <div className="flex flex-col items-center justify-center h-full">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-cyan-400"></div>
        <p className="mt-6 text-lg text-gray-300">{message}</p>
    </div>
);

const CallScreen: React.FC<{ transcript: TranscriptEntry[]; onStop: () => void }> = ({ transcript, onStop }) => {
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
      if(scrollRef.current){
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
    }, [transcript]);

    return (
        <div className="flex flex-col h-full">
            <div ref={scrollRef} className="flex-grow bg-gray-900/50 rounded-lg p-4 overflow-y-auto mb-4 space-y-4">
                {transcript.map((entry, index) => (
                    <div key={index} className={`flex items-start gap-3 ${entry.speaker === Speaker.AI ? 'justify-start' : 'justify-end'}`}>
                         {entry.speaker === Speaker.AI && <div className="w-8 h-8 rounded-full bg-cyan-500 flex items-center justify-center flex-shrink-0"><BrainIcon className="w-5 h-5 text-white" /></div>}
                        <div className={`max-w-xs md:max-w-md p-3 rounded-xl ${entry.speaker === Speaker.AI ? 'bg-gray-700 text-white rounded-tl-none' : 'bg-blue-600 text-white rounded-tr-none'}`}>
                            <p className={`${!entry.isFinal ? 'opacity-70' : ''}`}>{entry.text}</p>
                        </div>
                         {entry.speaker === Speaker.USER && <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0"><MicIcon className="w-5 h-5 text-white" /></div>}
                    </div>
                ))}
            </div>
            <div className="flex justify-center">
                <button onClick={onStop} className="bg-red-600 hover:bg-red-700 text-white font-bold py-4 px-8 rounded-full transition-transform transform hover:scale-105 shadow-lg flex items-center gap-2">
                    <PhoneIcon className="w-6 h-6 transform rotate-[135deg]" />
                    End Call
                </button>
            </div>
        </div>
    );
};

const ResultsScreen: React.FC<{ analysis: CallAnalysis | null; transcript: TranscriptEntry[]; onReset: () => void; recordedAudioUrl: string | null; }> = ({ analysis, transcript, onReset, recordedAudioUrl }) => (
    <div className="flex flex-col h-full">
        <div className="flex-grow overflow-y-auto space-y-6 pr-2">
            <h2 className="text-xl font-bold text-center text-cyan-400">Call Analysis Complete</h2>
            {analysis && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-700/50 p-4 rounded-lg">
                        <h3 className="font-semibold text-lg mb-2">Confirmed Slot</h3>
                        <p className="text-cyan-300 text-2xl font-mono">{analysis.confirmedSlot}</p>
                    </div>
                     <div className="bg-gray-700/50 p-4 rounded-lg">
                        <h3 className="font-semibold text-lg mb-2">Personality Analysis</h3>
                        <p className="text-gray-300">{analysis.personalityAnalysis}</p>
                    </div>
                    <div className="bg-gray-700/50 p-4 rounded-lg col-span-1 md:col-span-2">
                        <h3 className="font-semibold text-lg mb-2">Call Summary</h3>
                        <p className="text-gray-300">{analysis.summary}</p>
                    </div>
                </div>
            )}
            
            {recordedAudioUrl && (
                <div className="bg-gray-700/50 p-4 rounded-lg">
                    <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                        <PhoneIcon className="w-5 h-5 text-cyan-400"/>
                        Call Recording
                    </h3>
                    <audio controls className="w-full mb-3">
                        <source src={recordedAudioUrl} type="audio/webm" />
                        Your browser does not support the audio element.
                    </audio>
                    <a
                        href={recordedAudioUrl}
                        download="interview_call_recording.webm"
                        className="inline-flex items-center justify-center gap-2 w-full bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg transition-colors"
                    >
                        <DownloadIcon className="w-5 h-5" />
                        Download Recording
                    </a>
                </div>
            )}

            <div className="bg-gray-900/50 p-4 rounded-lg">
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                  <DocumentTextIcon className="w-6 h-6 text-cyan-400"/>
                  Full Transcript
                </h3>
                <div className="max-h-48 overflow-y-auto space-y-2 text-sm pr-2">
                    {transcript.filter(t => t.isFinal).map((entry, index) => (
                        <p key={index} className="text-gray-400">
                            <span className={`font-bold ${entry.speaker === Speaker.AI ? 'text-cyan-400' : 'text-blue-400'}`}>{entry.speaker}: </span>
                            {entry.text}
                        </p>
                    ))}
                </div>
            </div>
        </div>
        <div className="flex justify-center mt-6">
            <button onClick={onReset} className="bg-cyan-500 hover:bg-cyan-600 text-white font-bold py-3 px-8 rounded-full transition-transform transform hover:scale-105 shadow-lg">
                Start a New Call
            </button>
        </div>
    </div>
);

export default App;
