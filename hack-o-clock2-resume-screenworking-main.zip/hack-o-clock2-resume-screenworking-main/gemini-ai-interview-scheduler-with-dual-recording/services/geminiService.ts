
import { GoogleGenAI, LiveSession, LiveServerMessage, Modality, Type } from "@google/genai";
import { CallAnalysis, TranscriptEntry, Speaker } from '../types';

// --- Audio Utility Functions ---
function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

const CANDIDATE_NAME = "Alex";
const COMPANY_NAME = "InnovateTech";
const ROLE_NAME = "Senior React Engineer";

const SYSTEM_INSTRUCTION = `You are a friendly and professional AI hiring assistant from ${COMPANY_NAME}.
You are calling a candidate, ${CANDIDATE_NAME}, to schedule a technical interview for the ${ROLE_NAME} position.
Follow this script:
1. Greet the candidate: "Good morning, am I speaking with ${CANDIDATE_NAME}?"
2. Ask if it is a good time to talk.
3. If yes, state the purpose of your call.
4. Offer three specific interview slots: "Monday at 10 AM", "Wednesday at 2 PM", or "Friday at 4 PM".
5. Wait for the candidate to confirm one slot.
6. Once a slot is confirmed, repeat it back to them and say the call is complete.
7. End the call politely.
Keep your responses concise and natural.
`;

export const startLiveSession = (
    updateTranscript: (entry: TranscriptEntry) => void,
    handleAudioPlayback: (audio: string) => void,
    setConnectionError: (error: string) => void
): Promise<LiveSession> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
            systemInstruction: SYSTEM_INSTRUCTION,
            inputAudioTranscription: {},
            outputAudioTranscription: {},
        },
        callbacks: {
            onopen: () => { /* Connection opened */ },
            onmessage: (message: LiveServerMessage) => {
                if (message.serverContent?.inputTranscription) {
                    const { text, isFinal } = message.serverContent.inputTranscription;
                    updateTranscript({ speaker: Speaker.USER, text, isFinal });
                }
                if (message.serverContent?.outputTranscription) {
                    const { text, isFinal } = message.serverContent.outputTranscription;
                    updateTranscript({ speaker: Speaker.AI, text, isFinal });
                }
                const audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                if (audio) {
                    handleAudioPlayback(audio);
                }
            },
            onclose: () => { /* Connection closed */ },
            onerror: (e: ErrorEvent) => {
                console.error("Live session error:", e);
                setConnectionError("A connection error occurred. Please try again.");
            },
        },
    });
};

export const getPostCallAnalysis = async (transcript: TranscriptEntry[]): Promise<CallAnalysis | null> => {
    const fullTranscript = transcript
        .filter(t => t.isFinal)
        .map(t => `${t.speaker}: ${t.text}`)
        .join('\n');

    if (!fullTranscript) return null;

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Based on the following interview scheduling call transcript, provide a detailed analysis.
            Transcript:
            ---
            ${fullTranscript}
            ---
            `,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        confirmedSlot: {
                            type: Type.STRING,
                            description: "The specific date and time confirmed by the candidate. If not confirmed, state 'Not Confirmed'."
                        },
                        summary: {
                            type: Type.STRING,
                            description: "A brief, 2-3 sentence summary of the entire conversation."
                        },
                        personalityAnalysis: {
                            type: Type.STRING,
                            description: "Analyze the candidate's tone, confidence, and politeness based on their words. Provide a 2-3 sentence analysis."
                        }
                    },
                    required: ["confirmedSlot", "summary", "personalityAnalysis"]
                }
            }
        });

        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as CallAnalysis;
    } catch (error) {
        console.error("Error getting post-call analysis:", error);
        return null;
    }
};