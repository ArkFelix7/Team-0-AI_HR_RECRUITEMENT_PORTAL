
export enum CallState {
  IDLE,
  CONNECTING,
  ACTIVE,
  ANALYZING,
  ENDED,
  ERROR,
}

export enum Speaker {
  USER = 'User',
  AI = 'AI',
}

export interface TranscriptEntry {
  speaker: Speaker;
  text: string;
  isFinal: boolean;
}

export interface CallAnalysis {
  confirmedSlot: string;
  summary: string;
  personalityAnalysis: string;
}
