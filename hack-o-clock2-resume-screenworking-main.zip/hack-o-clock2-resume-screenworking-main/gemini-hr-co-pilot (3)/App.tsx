
import React, { useState } from 'react';
import { JobPostings } from './components/JobPostings';
import { CandidateList } from './components/CandidateList';
import { ImageAnalyzer } from './components/ImageAnalyzer';
import { UserGroupIcon, PhotoIcon, WandIcon, LoadingSpinner } from './components/icons';
import { JOBS_DATA } from './constants';
import type { Job, Applicant } from './types';
import { AppView } from './types';
import { Modal } from './components/Modal';
import { extractTextFromPdf } from './utils/pdf';

const AddJobForm: React.FC<{
  onAdd: (jobData: Omit<Job, 'id' | 'applicants'>) => void;
  onCancel: () => void;
}> = ({ onAdd, onCancel }) => {
  const [title, setTitle] = useState('');
  const [department, setDepartment] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !department || !description) return;
    onAdd({ title, department, description });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="title" className="block text-sm font-medium text-gray-300">Job Title</label>
        <input type="text" id="title" value={title} onChange={e => setTitle(e.target.value)} required className="mt-1 block w-full rounded-md border-0 bg-white/5 py-1.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-indigo-500" />
      </div>
      <div>
        <label htmlFor="department" className="block text-sm font-medium text-gray-300">Department</label>
        <input type="text" id="department" value={department} onChange={e => setDepartment(e.target.value)} required className="mt-1 block w-full rounded-md border-0 bg-white/5 py-1.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-indigo-500" />
      </div>
      <div>
        <label htmlFor="description" className="block text-sm font-medium text-gray-300">Description</label>
        <textarea id="description" value={description} onChange={e => setDescription(e.target.value)} rows={5} required className="mt-1 block w-full rounded-md border-0 bg-white/5 py-1.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-indigo-500" />
      </div>
      <div className="flex justify-end gap-3 pt-4">
        <button type="button" onClick={onCancel} className="px-4 py-2 text-sm font-semibold rounded-md bg-gray-600 hover:bg-gray-500">Cancel</button>
        <button type="submit" className="px-4 py-2 text-sm font-semibold rounded-md bg-indigo-500 hover:bg-indigo-400">Add Job</button>
      </div>
    </form>
  );
};

const AddCandidateForm: React.FC<{
  onAdd: (jobId: number, candidateData: Omit<Applicant, 'id' | 'analysis' | 'error'>) => void;
  onCancel: () => void;
  jobId: number;
}> = ({ onAdd, onCancel, jobId }) => {
    const [name, setName] = useState('');
    const [file, setFile] = useState<File | null>(null);
    const [isParsing, setIsParsing] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !file) {
            setError('Please provide a name and a resume file.');
            return;
        }
        setError('');
        setIsParsing(true);
        try {
            const resumeText = await extractTextFromPdf(file);
            onAdd(jobId, { name, resume: resumeText });
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to process PDF.');
        } finally {
            setIsParsing(false);
        }
    }
    
    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300">Candidate Name</label>
                <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="mt-1 block w-full rounded-md border-0 bg-white/5 py-1.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-indigo-500" />
            </div>
            <div>
                <label htmlFor="resume" className="block text-sm font-medium text-gray-300">Resume (PDF)</label>
                <input type="file" id="resume" onChange={e => setFile(e.target.files?.[0] || null)} accept=".pdf" required className="mt-1 block w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-500/20 file:text-indigo-300 hover:file:bg-indigo-500/30" />
            </div>
            {error && <p className="text-sm text-red-400">{error}</p>}
            <div className="flex justify-end gap-3 pt-4">
                <button type="button" onClick={onCancel} className="px-4 py-2 text-sm font-semibold rounded-md bg-gray-600 hover:bg-gray-500" disabled={isParsing}>Cancel</button>
                <button type="submit" className="px-4 py-2 text-sm font-semibold rounded-md bg-indigo-500 hover:bg-indigo-400 flex items-center gap-2 disabled:bg-gray-600" disabled={isParsing}>
                    {isParsing && <LoadingSpinner className="h-4 w-4" />}
                    {isParsing ? 'Processing...' : 'Add Candidate'}
                </button>
            </div>
        </form>
    );
};

const App: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>(JOBS_DATA);
  const [selectedJobId, setSelectedJobId] = useState<number | null>(jobs[0]?.id || null);
  const [activeView, setActiveView] = useState<AppView>(AppView.HR);
  const [isAddJobModalOpen, setIsAddJobModalOpen] = useState(false);
  const [isAddCandidateModalOpen, setIsAddCandidateModalOpen] = useState(false);

  const selectedJob = jobs.find(job => job.id === selectedJobId);

  const handleAddJob = (newJobData: Omit<Job, 'id' | 'applicants'>) => {
    const newJob: Job = {
        ...newJobData,
        id: Date.now(),
        applicants: []
    };
    const updatedJobs = [...jobs, newJob];
    setJobs(updatedJobs);
    setSelectedJobId(newJob.id);
    setIsAddJobModalOpen(false);
  };

  const handleRemoveJob = (jobIdToRemove: number) => {
    const updatedJobs = jobs.filter(job => job.id !== jobIdToRemove);
    setJobs(updatedJobs);
    if (selectedJobId === jobIdToRemove) {
        setSelectedJobId(updatedJobs.length > 0 ? updatedJobs[0].id : null);
    }
  };

  const handleAddCandidate = (jobId: number, newCandidate: Omit<Applicant, 'id' | 'analysis' | 'error'>) => {
      const newApplicant: Applicant = {
          ...newCandidate,
          id: Date.now(),
          analysis: null
      };
      setJobs(prevJobs => prevJobs.map(job => 
          job.id === jobId 
              ? { ...job, applicants: [...job.applicants, newApplicant] }
              : job
      ));
      setIsAddCandidateModalOpen(false);
  };
  
  const handleRemoveCandidate = (jobId: number, candidateIdToRemove: number) => {
      setJobs(prevJobs => prevJobs.map(job => {
          if (job.id === jobId) {
              return { ...job, applicants: job.applicants.filter(app => app.id !== candidateIdToRemove)};
          }
          return job;
      }));
  };

  const handleUpdateAnalysis = (jobId: number, updatedApplicants: Applicant[]) => {
    setJobs(prevJobs => prevJobs.map(job => 
        job.id === jobId 
            ? { ...job, applicants: updatedApplicants }
            : job
    ));
  };


  const TabButton: React.FC<{
    view: AppView;
    label: string;
    icon: React.ReactNode;
  }> = ({ view, label, icon }) => (
    <button
      onClick={() => setActiveView(view)}
      className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md transition-colors ${
        activeView === view
          ? 'bg-indigo-500 text-white'
          : 'text-gray-300 hover:bg-gray-700 hover:text-white'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <div className="h-screen w-screen bg-gray-900 text-gray-100 flex flex-col font-sans">
      <header className="flex items-center justify-between p-3 border-b border-gray-700 bg-gray-800/50 backdrop-blur-sm">
        <div className="flex items-center gap-3">
            <WandIcon className="h-8 w-8 text-indigo-400" />
            <h1 className="text-xl font-bold text-white">Gemini HR Co-Pilot</h1>
        </div>
        <nav className="flex items-center gap-2 p-1 bg-gray-700/50 rounded-lg">
          <TabButton view={AppView.HR} label="Resume Matcher" icon={<UserGroupIcon className="h-5 w-5" />} />
          <TabButton view={AppView.ImageAnalyzer} label="Image Analyzer" icon={<PhotoIcon className="h-5 w-5" />} />
        </nav>
      </header>

      <main className="flex-grow overflow-hidden">
        {activeView === AppView.HR ? (
            <div className="flex h-full">
            <aside className="w-1/4 min-w-[250px] max-w-[350px] border-r border-gray-700">
                <JobPostings
                jobs={jobs}
                selectedJobId={selectedJobId}
                onSelectJob={setSelectedJobId}
                onAddJob={() => setIsAddJobModalOpen(true)}
                onRemoveJob={handleRemoveJob}
                />
            </aside>
            <section className="flex-grow bg-gray-800">
                {selectedJob ? (
                <CandidateList 
                    key={selectedJob.id} 
                    job={selectedJob} 
                    onAddCandidate={() => setIsAddCandidateModalOpen(true)}
                    onRemoveCandidate={(candidateId) => handleRemoveCandidate(selectedJob.id, candidateId)}
                    onUpdateAnalysis={handleUpdateAnalysis}
                />
                ) : (
                <div className="flex flex-col items-center justify-center h-full text-gray-500">
                    <p>No job postings available.</p>
                    <button onClick={() => setIsAddJobModalOpen(true)} className="mt-4 px-4 py-2 text-sm font-semibold rounded-md bg-indigo-500 text-white hover:bg-indigo-400">
                        Create Your First Job Posting
                    </button>
                </div>
                )}
            </section>
            </div>
        ) : (
            <ImageAnalyzer />
        )}
      </main>
      
      {isAddJobModalOpen && (
        <Modal title="Add New Job Posting" onClose={() => setIsAddJobModalOpen(false)}>
            <AddJobForm onAdd={handleAddJob} onCancel={() => setIsAddJobModalOpen(false)} />
        </Modal>
      )}

      {isAddCandidateModalOpen && selectedJob && (
        <Modal title={`Add Candidate to "${selectedJob.title}"`} onClose={() => setIsAddCandidateModalOpen(false)}>
            <AddCandidateForm onAdd={handleAddCandidate} onCancel={() => setIsAddCandidateModalOpen(false)} jobId={selectedJob.id} />
        </Modal>
      )}

    </div>
  );
};

export default App;
