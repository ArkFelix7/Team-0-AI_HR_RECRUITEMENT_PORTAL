
import React from 'react';
import type { Applicant } from '../types';

interface AnalysisDetailsProps {
  applicant: Applicant | null;
}

export const AnalysisDetails: React.FC<AnalysisDetailsProps> = ({ applicant }) => {
  if (!applicant) {
    return (
      <div className="flex items-center justify-center h-full text-gray-400">
        <p>Select a candidate to see their detailed analysis.</p>
      </div>
    );
  }

  if (applicant.error) {
    return (
      <div className="p-6 text-center">
        <h3 className="text-xl font-bold text-white mb-2">{applicant.name}</h3>
        <div className="bg-red-900/50 p-4 rounded-lg">
          <h4 className="text-lg font-semibold text-red-300 mb-2">Analysis Failed</h4>
          <p className="text-red-400">{applicant.error}</p>
        </div>
      </div>
    );
  }

  if (!applicant.analysis) {
    return (
      <div className="p-6 text-center">
        <h3 className="text-xl font-bold text-white mb-2">{applicant.name}</h3>
        <p className="text-gray-400">This candidate has not been analyzed yet.</p>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 h-full overflow-y-auto">
      <h3 className="text-2xl font-bold text-white mb-4 sticky top-0 bg-gray-800 py-2">{applicant.name}</h3>
      <div className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-green-400 mb-2">Strengths</h4>
          <p className="text-gray-300 whitespace-pre-line leading-relaxed">{applicant.analysis.strengths}</p>
        </div>
        <div>
          <h4 className="text-lg font-semibold text-orange-400 mb-2">Potential Gaps</h4>
          <p className="text-gray-300 whitespace-pre-line leading-relaxed">{applicant.analysis.weaknesses}</p>
        </div>
      </div>
    </div>
  );
};
