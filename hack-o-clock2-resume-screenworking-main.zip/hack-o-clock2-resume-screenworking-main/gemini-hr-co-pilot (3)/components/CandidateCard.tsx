
import React from 'react';
import type { Applicant } from '../types';
import { TrashIcon } from './icons';

interface CandidateCardProps {
  applicant: Applicant;
  onSelect: () => void;
  onRemove: () => void;
  isSelected: boolean;
}

const getScoreColor = (score: number): string => {
  if (score >= 85) return 'bg-green-500 text-green-50';
  if (score >= 70) return 'bg-yellow-500 text-yellow-50';
  if (score >= 50) return 'bg-orange-500 text-orange-50';
  return 'bg-red-500 text-red-50';
};

export const CandidateCard: React.FC<CandidateCardProps> = ({ applicant, onSelect, onRemove, isSelected }) => {
  const handleRemove = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent onSelect from firing
    if(window.confirm(`Are you sure you want to remove ${applicant.name}?`)) {
        onRemove();
    }
  }

  return (
    <div
      onClick={onSelect}
      className={`p-4 rounded-lg shadow-md cursor-pointer transition-all duration-200 ease-in-out relative group ${isSelected ? 'bg-indigo-600/30 ring-2 ring-indigo-500' : 'bg-gray-700/50 hover:bg-gray-600/50'}`}
    >
      <div className="flex justify-between items-center">
        <h4 className="font-bold text-lg text-gray-100">{applicant.name}</h4>
        {applicant.analysis && (
          <span className={`px-3 py-1 text-sm font-bold rounded-full ${getScoreColor(applicant.analysis.score)}`}>
            {applicant.analysis.score}
          </span>
        )}
      </div>
      {applicant.error && (
        <p className="text-sm text-red-400 mt-2">Error: {applicant.error}</p>
      )}
      <button 
        onClick={handleRemove}
        className="absolute top-2 right-2 p-1 rounded-full bg-gray-800/50 text-gray-400 opacity-0 group-hover:opacity-100 hover:bg-red-500/50 hover:text-white transition-opacity"
        aria-label={`Remove ${applicant.name}`}
      >
        <TrashIcon className="h-4 w-4" />
      </button>
    </div>
  );
};
