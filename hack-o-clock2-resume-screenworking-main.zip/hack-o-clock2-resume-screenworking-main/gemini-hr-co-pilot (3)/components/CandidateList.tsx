
import React, { useState, useEffect, useCallback } from 'react';
import type { Job, Applicant } from '../types';
import { analyzeResume } from '../services/geminiService';
import { CandidateCard } from './CandidateCard';
import { AnalysisDetails } from './AnalysisDetails';
import { LoadingSpinner, WandIcon, PlusCircleIcon } from './icons';

interface CandidateListProps {
  job: Job;
  onAddCandidate: () => void;
  onRemoveCandidate: (candidateId: number) => void;
  onUpdateAnalysis: (jobId: number, updatedApplicants: Applicant[]) => void;
}

export const CandidateList: React.FC<CandidateListProps> = ({ job, onAddCandidate, onRemoveCandidate, onUpdateAnalysis }) => {
  const [applicants, setApplicants] = useState<Applicant[]>([]);
  const [selectedApplicantId, setSelectedApplicantId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const sortedApplicants = [...job.applicants].sort((a, b) => {
        if (a.analysis && b.analysis) return b.analysis.score - a.analysis.score;
        if (a.analysis) return -1;
        if (b.analysis) return 1;
        return 0;
    });
    setApplicants(sortedApplicants);

    if (selectedApplicantId && !job.applicants.some(a => a.id === selectedApplicantId)) {
      setSelectedApplicantId(sortedApplicants.length > 0 ? sortedApplicants[0].id : null);
    } else if (!selectedApplicantId && sortedApplicants.length > 0) {
      setSelectedApplicantId(sortedApplicants[0].id);
    } else if (job.applicants.length === 0) {
      setSelectedApplicantId(null);
    }
  }, [job.applicants]);

  const handleAnalysis = useCallback(async () => {
    setIsLoading(true);

    const analysisPromises = job.applicants.map(async (applicant) => {
      try {
        const result = await analyzeResume(applicant.resume, job.description);
        return { ...applicant, analysis: result, error: undefined };
      } catch (error) {
        return { ...applicant, analysis: { ...applicant.analysis, score: 0 }, error: error instanceof Error ? error.message : 'Analysis failed' };
      }
    });

    const results = await Promise.all(analysisPromises);
    onUpdateAnalysis(job.id, results);
    setIsLoading(false);
  }, [job.id, job.applicants, job.description, onUpdateAnalysis]);
  
  const selectedApplicant = applicants.find(a => a.id === selectedApplicantId) || null;

  return (
    <div className="flex flex-col md:flex-row h-full">
      <div className="w-full md:w-1/3 border-r border-gray-700 p-4 flex flex-col">
        <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-white truncate pr-2">Candidates for {job.title}</h3>
            <button onClick={onAddCandidate} className="text-indigo-400 hover:text-indigo-300 flex-shrink-0" aria-label="Add new candidate">
                <PlusCircleIcon className="h-7 w-7" />
            </button>
        </div>
        
        <button
          onClick={handleAnalysis}
          disabled={isLoading || applicants.length === 0}
          className="w-full flex justify-center items-center gap-2 mb-4 rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
        >
          {isLoading ? <LoadingSpinner className="h-5 w-5" /> : <WandIcon className="h-5 w-5" />}
          <span>{isLoading ? 'Analyzing...' : `Analyze ${applicants.length} Candidates`}</span>
        </button>
        <div className="space-y-3 overflow-y-auto flex-grow">
          {applicants.length > 0 ? applicants.map(applicant => (
            <CandidateCard
              key={applicant.id}
              applicant={applicant}
              onSelect={() => setSelectedApplicantId(applicant.id)}
              onRemove={() => onRemoveCandidate(applicant.id)}
              isSelected={selectedApplicantId === applicant.id}
            />
          )) : (
            <div className="text-center text-gray-500 mt-8 p-4 border border-dashed border-gray-700 rounded-lg">
                <p>No candidates yet.</p>
                <p className="text-sm">Click the <PlusCircleIcon className="h-4 w-4 inline-block -mt-1"/> icon to add one.</p>
            </div>
          )}
        </div>
      </div>
      <div className="w-full md:w-2/3 bg-gray-800">
        <AnalysisDetails applicant={selectedApplicant} />
      </div>
    </div>
  );
};
