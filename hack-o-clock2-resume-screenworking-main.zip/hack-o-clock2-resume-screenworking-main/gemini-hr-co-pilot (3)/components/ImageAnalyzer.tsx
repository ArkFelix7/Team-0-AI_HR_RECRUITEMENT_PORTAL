
import React, { useState, useCallback } from 'react';
import { analyzeImage } from '../services/geminiService';
import { LoadingSpinner, WandIcon } from './icons';

const fileToGenerativePart = async (file: File): Promise<{ mimeType: string; data: string; }> => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result.split(',')[1]);
      } else {
        resolve('');
      }
    };
    reader.readAsDataURL(file);
  });
  return {
    mimeType: file.type,
    data: await base64EncodedDataPromise,
  };
};

export const ImageAnalyzer: React.FC = () => {
  const [prompt, setPrompt] = useState<string>('');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAnalyzeClick = useCallback(async () => {
    if (!imageFile || !prompt) {
      setError('Please provide both an image and a prompt.');
      return;
    }

    setIsLoading(true);
    setError('');
    setAnalysis('');

    try {
      const imagePart = await fileToGenerativePart(imageFile);
      const result = await analyzeImage(prompt, imagePart.data, imagePart.mimeType);
      setAnalysis(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [imageFile, prompt]);

  return (
    <div className="p-4 sm:p-6 lg:p-8 text-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-2xl sm:text-3xl font-bold text-center mb-6">Gemini Image Analyzer</h2>
        <div className="bg-gray-800 rounded-2xl shadow-xl p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex flex-col space-y-4">
            <div>
              <label htmlFor="image-upload" className="block text-sm font-medium text-gray-300 mb-2">Upload Image</label>
              <div className="mt-2 flex justify-center rounded-lg border border-dashed border-gray-600 px-6 py-10 hover:border-indigo-400 transition">
                <div className="text-center">
                   {imagePreview ? (
                     <img src={imagePreview} alt="Preview" className="mx-auto h-40 w-auto rounded-md object-cover" />
                    ) : (
                    <svg className="mx-auto h-12 w-12 text-gray-500" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M1.5 6a2.25 2.25 0 012.25-2.25h16.5A2.25 2.25 0 0122.5 6v12a2.25 2.25 0 01-2.25 2.25H3.75A2.25 2.25 0 011.5 18V6zM3 16.06l2.755-2.755a.75.75 0 011.06 0l3.072 3.072a.75.75 0 001.06 0l3.808-3.808a.75.75 0 011.06 0l2.97 2.97V6H3v10.06z" clipRule="evenodd" />
                    </svg>
                    )}
                  <div className="mt-4 flex text-sm leading-6 text-gray-400">
                    <label htmlFor="file-upload" className="relative cursor-pointer rounded-md bg-gray-800 font-semibold text-indigo-400 focus-within:outline-none focus-within:ring-2 focus-within:ring-indigo-500 focus-within:ring-offset-2 focus-within:ring-offset-gray-900 hover:text-indigo-300">
                      <span>Upload a file</span>
                      <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*" />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                   <p className="text-xs leading-5 text-gray-500">PNG, JPG, GIF up to 10MB</p>
                </div>
              </div>
            </div>
            <div>
              <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-2">Your Prompt</label>
              <textarea
                id="prompt"
                rows={3}
                className="block w-full rounded-md border-0 bg-white/5 py-1.5 text-white shadow-sm ring-1 ring-inset ring-white/10 focus:ring-2 focus:ring-inset focus:ring-indigo-500 sm:text-sm sm:leading-6 placeholder:text-gray-500"
                placeholder="e.g., What is in this image? Describe it in detail."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
            </div>
            <button
              onClick={handleAnalyzeClick}
              disabled={isLoading || !imageFile || !prompt}
              className="w-full flex justify-center items-center gap-2 rounded-md bg-indigo-500 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
            >
              {isLoading ? <LoadingSpinner className="h-5 w-5" /> : <WandIcon className="h-5 w-5" />}
              <span>{isLoading ? 'Analyzing...' : 'Analyze Image'}</span>
            </button>
            {error && <p className="text-sm text-red-400">{error}</p>}
          </div>
          
          <div className="bg-gray-900 rounded-lg p-4 h-96 overflow-y-auto">
             <h3 className="text-lg font-semibold text-gray-200 mb-2">Analysis Result</h3>
            {isLoading ? (
              <div className="flex items-center justify-center h-full">
                <LoadingSpinner className="h-8 w-8 text-indigo-400" />
              </div>
            ) : analysis ? (
              <p className="text-gray-300 whitespace-pre-wrap">{analysis}</p>
            ) : (
              <p className="text-gray-500 text-center mt-16">The analysis from Gemini will appear here.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
