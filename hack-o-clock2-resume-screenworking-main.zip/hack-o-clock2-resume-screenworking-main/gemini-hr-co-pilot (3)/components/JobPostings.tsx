
import React from 'react';
import type { Job } from '../types';
import { PlusCircleIcon, TrashIcon } from './icons';

interface JobPostingsProps {
  jobs: Job[];
  selectedJobId: number | null;
  onSelectJob: (id: number) => void;
  onAddJob: () => void;
  onRemoveJob: (id: number) => void;
}

export const JobPostings: React.FC<JobPostingsProps> = ({ jobs, selectedJobId, onSelectJob, onAddJob, onRemoveJob }) => {
  
  const handleRemove = (e: React.MouseEvent, job: Job) => {
    e.stopPropagation();
    if(window.confirm(`Are you sure you want to remove the posting for "${job.title}"?`)) {
        onRemoveJob(job.id);
    }
  }

  return (
    <div className="p-4 bg-gray-900 h-full overflow-y-auto flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold text-white">Job Postings</h2>
        <button onClick={onAddJob} className="text-indigo-400 hover:text-indigo-300" aria-label="Add new job posting">
            <PlusCircleIcon className="h-7 w-7" />
        </button>
      </div>
      <div className="space-y-3 flex-grow">
        {jobs.map(job => (
          <div
            key={job.id}
            onClick={() => onSelectJob(job.id)}
            className={`p-4 rounded-lg cursor-pointer transition-colors relative group ${
              selectedJobId === job.id
                ? 'bg-indigo-600/30 ring-2 ring-indigo-500 text-white'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            <h3 className="font-bold">{job.title}</h3>
            <p className="text-sm text-gray-400">{job.department}</p>
            <button
                onClick={(e) => handleRemove(e, job)}
                className="absolute top-2 right-2 p-1 rounded-full bg-gray-900/50 text-gray-400 opacity-0 group-hover:opacity-100 hover:bg-red-500/50 hover:text-white transition-opacity"
                aria-label={`Remove ${job.title}`}
            >
                <TrashIcon className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
