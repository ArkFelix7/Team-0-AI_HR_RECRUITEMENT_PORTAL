
import React, { PropsWithChildren } from 'react';

interface ModalProps {
  title: string;
  onClose: () => void;
}

export const Modal: React.FC<PropsWithChildren<ModalProps>> = ({ title, onClose, children }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      <div className="fixed inset-0" onClick={onClose} aria-hidden="true"></div>
      <div className="relative w-full max-w-lg p-6 bg-gray-800 rounded-2xl shadow-xl text-white mx-4">
        <div className="flex items-center justify-between pb-3 border-b border-gray-700">
          <h3 className="text-xl font-bold" id="modal-title">{title}</h3>
          <button onClick={onClose} className="p-1 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
             <span className="sr-only">Close modal</span>
          </button>
        </div>
        <div className="mt-4">
          {children}
        </div>
      </div>
    </div>
  );
};
