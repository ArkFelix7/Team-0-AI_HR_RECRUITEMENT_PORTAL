
import React from 'react';

export const LoadingSpinner: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={`animate-spin ${className}`}
  >
    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
  </svg>
);

export const WandIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M9.528 1.718a.75.75 0 0 1 .162.819A8.97 8.97 0 0 0 9 6a9 9 0 0 0 9 9 8.97 8.97 0 0 0 3.463-.69a.75.75 0 0 1 .981.981A10.501 10.501 0 0 1 18 16.5a10.5 10.5 0 1 1-10.5-10.5c0-.178.005-.355.014-.532a.75.75 0 0 1 .819-.162l4.995 2.5a.75.75 0 0 1 0 1.328l-4.995 2.5a.75.75 0 0 1-1.132-.981l1.68-3.359a.75.75 0 0 1 0-.664l-1.68-3.359a.75.75 0 0 1 .313-1.132l4.995-2.5a.75.75 0 0 1 1.328 0l4.995 2.5a.75.75 0 0 1-.981 1.132l-1.68-1.68a.75.75 0 0 1-.664 0l-1.68 1.68a.75.75 0 0 1-.981-1.132L12 6.38l-1.323 2.647a.75.75 0 0 1-1.132-.981l1.68-3.359a.75.75 0 0 1 .664 0l1.68 3.359a.75.75 0 0 1-1.132.981L9.528 6.38z" clipRule="evenodd" />
    </svg>
);

export const UserGroupIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M4.5 6.375a4.125 4.125 0 1 1 8.25 0 4.125 4.125 0 0 1-8.25 0ZM14.25 8.625a3.375 3.375 0 1 1 6.75 0 3.375 3.375 0 0 1-6.75 0ZM1.5 19.125a7.125 7.125 0 0 1 14.25 0v.003l-.001.119a.75.75 0 0 1-.363.63A13.067 13.067 0 0 1 8.625 22.5c-2.707 0-5.27-.608-7.5-1.74a.75.75 0 0 1-.364-.63l-.001-.12v-.003ZM12.375 19.125a7.125 7.125 0 0 1 14.25 0v.003l-.001.119a.75.75 0 0 1-.363.63A13.067 13.067 0 0 1 19.625 22.5c-2.707 0-5.27-.608-7.5-1.74a.75.75 0 0 1-.364-.63l-.001-.12v-.003Z" />
    </svg>
);

export const PhotoIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M1.5 6a2.25 2.25 0 0 1 2.25-2.25h16.5A2.25 2.25 0 0 1 22.5 6v12a2.25 2.25 0 0 1-2.25 2.25H3.75A2.25 2.25 0 0 1 1.5 18V6ZM3 16.06l2.755-2.755a.75.75 0 0 1 1.06 0l3.072 3.072a.75.75 0 0 0 1.06 0l3.808-3.808a.75.75 0 0 1 1.06 0l2.97 2.97V6H3v10.06Z" clipRule="evenodd" />
    </svg>
);

export const TrashIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M16.5 4.478v.227a48.816 48.816 0 0 1 3.878.512.75.75 0 1 1-.256 1.478l-.209-.035-1.005 13.006a.75.75 0 0 1-.744.734H5.786a.75.75 0 0 1-.744-.734L4.035 6.66l-.209.035a.75.75 0 0 1-.256-1.478A48.567 48.567 0 0 1 7.5 4.705v-.227c0-1.564 1.213-2.9 2.816-2.9h1.368c1.603 0 2.816 1.336 2.816 2.9ZM5.25 6.75l.04.52a.75.75 0 0 0 .746.671h12.927a.75.75 0 0 0 .746-.67l.04-.522a49.94 49.94 0 0 0-14.5-1.128ZM8.25 8.25a.75.75 0 0 1 .75.75v8.25a.75.75 0 0 1-1.5 0v-8.25a.75.75 0 0 1 .75-.75Zm3.75 0a.75.75 0 0 1 .75.75v8.25a.75.75 0 0 1-1.5 0v-8.25a.75.75 0 0 1 .75-.75Zm3.75 0a.75.75 0 0 1 .75.75v8.25a.75.75 0 0 1-1.5 0v-8.25a.75.75 0 0 1 .75-.75Z" clipRule="evenodd" />
    </svg>
);

export const PlusCircleIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25ZM12.75 9a.75.75 0 0 0-1.5 0v2.25H9a.75.75 0 0 0 0 1.5h2.25V15a.75.75 0 0 0 1.5 0v-2.25H15a.75.75 0 0 0 0-1.5h-2.25V9Z" clipRule="evenodd" />
    </svg>
);
