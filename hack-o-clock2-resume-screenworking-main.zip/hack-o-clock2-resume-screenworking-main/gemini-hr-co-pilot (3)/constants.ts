
import { Job } from './types';

export const JOBS_DATA: Job[] = [
  {
    id: 1,
    title: 'Senior Frontend Engineer',
    department: 'Engineering',
    description: `We are looking for an experienced Senior Frontend Engineer to join our dynamic team. The ideal candidate will have a strong background in React, TypeScript, and modern web technologies. You will be responsible for building and maintaining high-quality user interfaces, collaborating with backend developers and designers, and mentoring junior engineers. Key requirements include 5+ years of experience, proficiency with state management libraries like Redux or Zustand, and a deep understanding of component-based architecture. Experience with GraphQL is a plus.`,
    applicants: [
      {
        id: 101,
        name: 'Alice Johnson',
        resume: `Alice Johnson - Frontend Developer\n\nExperience:\n- 6 years at TechSolutions Inc. developing complex UIs with React and Redux.\n- Led a team to migrate a legacy Angular app to React, improving performance by 40%.\n- Proficient in TypeScript, Next.js, and Jest for testing.\n\nSkills: React, Redux, TypeScript, JavaScript, HTML, CSS, Next.js, GraphQL, Jest.`,
      },
      {
        id: 102,
        name: 'Bob Williams',
        resume: `Bob Williams - Web Developer\n\nSummary:\n- 4 years of experience building responsive websites. Primarily worked with Vue.js and a bit of React.\n- Strong eye for design and user experience.\n\nSkills: Vue.js, JavaScript, HTML, CSS, Figma. Some experience with React and TypeScript.`,
      },
      {
        id: 103,
        name: 'Charlie Brown',
        resume: `Charlie Brown - Full Stack Engineer\n\nExperience:\n- 7 years at DataCorp, working on both frontend and backend systems.\n- Backend expertise in Node.js, Express, and PostgreSQL.\n- Frontend work includes building dashboards with React and D3.js.\n- Strong believer in end-to-end ownership.\n\nSkills: Node.js, Express, PostgreSQL, React, D3.js, TypeScript, Docker.`,
      },
    ],
  },
  {
    id: 2,
    title: 'UX/UI Designer',
    department: 'Design',
    description: `Our design team is seeking a talented UX/UI Designer to create intuitive and beautiful user experiences. You will be involved in the entire design process, from user research and wireframing to creating high-fidelity mockups and prototypes. You must have a strong portfolio showcasing your work. Proficiency in Figma, Sketch, or Adobe XD is required. Collaboration and communication skills are essential. A passion for user-centered design is a must.`,
    applicants: [
      {
        id: 201,
        name: 'Diana Prince',
        resume: `Diana Prince - Product Designer\n\nPortfolio: link-to-portfolio\n\nSummary: 5 years of experience in UX/UI design for mobile and web applications. Expert in Figma and Adobe Creative Suite. Led the redesign of a major e-commerce app, resulting in a 25% increase in user engagement. Strong background in user research, usability testing, and interaction design.`,
      },
      {
        id: 202,
        name: 'Eve Adams',
        resume: `Eve Adams - Graphic Designer\n\nSummary: Creative graphic designer with 3 years of experience in branding and marketing materials. Eager to transition into a UX/UI role. Proficient in Adobe Photoshop and Illustrator. Completed a 6-month UX design bootcamp. Quick learner and team player.`,
      },
    ],
  },
];
