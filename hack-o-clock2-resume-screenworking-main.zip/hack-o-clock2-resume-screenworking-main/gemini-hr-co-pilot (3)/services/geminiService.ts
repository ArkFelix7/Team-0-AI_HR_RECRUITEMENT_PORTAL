
import { GoogleGenAI, Type } from '@google/genai';
import type { AnalysisResult } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema = {
  type: Type.OBJECT,
  properties: {
    score: {
      type: Type.INTEGER,
      description: 'A compatibility score from 0 to 100, where 100 is a perfect match.',
    },
    strengths: {
      type: Type.STRING,
      description: 'A concise summary of why the candidate is a good fit, highlighting key skills and experiences that align with the job description. Use bullet points.',
    },
    weaknesses: {
      type: Type.STRING,
      description: 'A list of potential gaps or areas where the candidate\'s profile is weaker in relation to the job requirements. Use bullet points.',
    },
  },
  required: ['score', 'strengths', 'weaknesses'],
};

export const analyzeResume = async (resume: string, jobDescription: string): Promise<AnalysisResult> => {
  const prompt = `
    Job Description:
    ---
    ${jobDescription}
    ---

    Candidate's Resume:
    ---
    ${resume}
    ---

    Please provide your analysis in the specified JSON format. The analysis should include:
    1. A compatibility score from 0 to 100, where 100 is a perfect match.
    2. A concise summary of why the candidate is a good fit, highlighting key skills and experiences that align with the job description in bullet points.
    3. A list of potential gaps or areas where the candidate's profile is weaker in relation to the job requirements in bullet points.
    `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: analysisSchema,
        thinkingConfig: { thinkingBudget: 32768 },
      },
    });

    const jsonString = response.text.trim();
    const result = JSON.parse(jsonString);
    
    return result as AnalysisResult;
  } catch (error) {
    console.error("Error analyzing resume:", error);
    throw new Error("Failed to analyze resume with Gemini API.");
  }
};

export const analyzeImage = async (prompt: string, imageBase64: string, mimeType: string): Promise<string> => {
    try {
        const imagePart = {
            inlineData: {
                data: imageBase64,
                mimeType: mimeType,
            },
        };
        const textPart = { text: prompt };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] },
        });

        return response.text;
    } catch (error) {
        console.error("Error analyzing image:", error);
        throw new Error("Failed to analyze image with Gemini API.");
    }
};
