
export interface AnalysisResult {
  score: number;
  strengths: string;
  weaknesses: string;
}

export interface Applicant {
  id: number;
  name: string;
  resume: string;
  analysis?: AnalysisResult | null;
  error?: string;
}

export interface Job {
  id: number;
  title: string;
  department: string;
  description: string;
  applicants: Applicant[];
}

export enum AppView {
  HR = 'HR',
  ImageAnalyzer = 'ImageAnalyzer',
}
