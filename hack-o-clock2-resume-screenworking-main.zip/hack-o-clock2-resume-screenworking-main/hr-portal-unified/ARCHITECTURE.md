# 🏗️ HR Portal - System Architecture

## 📐 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER INTERFACE                          │
│                     (React + TypeScript)                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │   JobList    │  │ CandidateList│  │CandidateDetail│        │
│  │              │  │              │  │              │        │
│  │ • Create job │  │ • Add cand.  │  │ • View all   │        │
│  │ • View jobs  │  │ • Upload PDF │  │ • Resume tab │        │
│  │ • Delete job │  │ • Analyze AI │  │ • Call tab   │        │
│  └──────┬───────┘  └──────┬───────┘  │ • Interview  │        │
│         │                 │           └──────┬───────┘        │
└─────────┼─────────────────┼──────────────────┼────────────────┘
          │                 │                  │
          ▼                 ▼                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                       SERVICE LAYER                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌────────────────────────┐      ┌─────────────────────┐      │
│  │  supabaseService.ts    │      │  geminiService.ts   │      │
│  │                        │      │                     │      │
│  │ • Job CRUD             │      │ • analyzeResume()   │      │
│  │ • Candidate CRUD       │      │ • analyzeCall()     │      │
│  │ • Resume Analysis CRUD │      │ • analyzeInterview()│      │
│  │ • Call Session CRUD    │      │                     │      │
│  │ • Video Interview CRUD │      │ (Google Gemini AI)  │      │
│  │ • File Upload/Delete   │      └─────────────────────┘      │
│  └───────────┬────────────┘                                    │
└──────────────┼─────────────────────────────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────────────┐
│                    SUPABASE BACKEND                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────┐          ┌──────────────────────┐    │
│  │   PostgreSQL DB     │          │   Storage Buckets    │    │
│  │                     │          │                      │    │
│  │ • jobs              │          │ • resumes/           │    │
│  │ • candidates        │          │ • call-recordings/   │    │
│  │ • resume_analysis   │          │ • video-interviews/  │    │
│  │ • call_sessions     │          │                      │    │
│  │ • video_interviews  │          │ (Files: PDF, WebM)   │    │
│  │ • interview_analysis│          └──────────────────────┘    │
│  └─────────────────────┘                                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Diagrams

### 1️⃣ Resume Screening Flow

```
┌──────────┐
│   HR     │
│ (User)   │
└────┬─────┘
     │ 1. Create Job
     ▼
┌─────────────┐
│  JobList    │ ──────► supabase.from('jobs').insert()
│ Component   │
└─────────────┘
     │
     │ 2. Add Candidate + PDF
     ▼
┌─────────────┐
│ CandidateList│──┐
│  Component   │  │ a. Extract PDF text
└──────────────┘  │    (pdfParser.ts)
     │            │
     │            ▼
     │       ┌──────────────┐
     │       │  Resume Text │
     │       └──────────────┘
     │            │
     │            ├──► Upload PDF to Storage
     │            │
     │            └──► supabase.from('candidates').insert({
     │                    resume_text,
     │                    resume_file_url
     │                })
     │
     │ 3. Click "Analyze Candidates"
     ▼
┌─────────────────┐
│ geminiService.  │──► Gemini API
│ analyzeResume() │    (AI Analysis)
└────────┬────────┘
         │ Returns: { score, strengths, weaknesses }
         ▼
┌──────────────────┐
│ supabase.from(   │
│ 'resume_analysis'│
│ ).insert()       │
└──────────────────┘
         │
         ▼
┌──────────────────┐
│ Update Rankings  │
│ for all candidates│
└──────────────────┘
```

---

### 2️⃣ Call Scheduling Flow (Future Integration)

```
┌──────────────┐
│ CandidateDetail│
│   Component   │
└───────┬────────┘
        │ 1. Click "Schedule Call"
        ▼
┌──────────────────┐
│  CallScheduler   │  (To be integrated)
│   Component      │
└────────┬─────────┘
         │ 2. Conduct call
         │    - Record audio
         │    - Generate transcript
         ▼
┌─────────────────┐
│ AI Gemini       │
│ Live Session    │
└────────┬────────┘
         │ 3. Call ends
         ▼
┌─────────────────────┐
│ geminiService.      │──► Analyze transcript
│ analyzeCallTranscript()│
└────────┬────────────┘
         │ Returns: { confirmedSlot, summary, 
         │           personalityAnalysis }
         ▼
┌──────────────────┐
│ Upload audio to  │
│ Storage          │
└────────┬─────────┘
         │
         ▼
┌────────────────────┐
│ supabase.from(     │
│ 'call_sessions'    │
│ ).insert({         │
│   call_audio_url,  │
│   transcript,      │
│   analysis...      │
│ })                 │
└────────────────────┘
         │
         ▼
┌────────────────────┐
│ Update candidate   │
│ status to          │
│ 'CALL_COMPLETED'   │
└────────────────────┘
```

---

### 3️⃣ Video Interview Flow (Future Integration)

```
┌──────────────┐
│ CandidateDetail│
│   Component   │
└───────┬────────┘
        │ 1. Click "Start Interview"
        ▼
┌──────────────────┐
│ VideoInterview   │  (To be integrated)
│   Component      │
└────────┬─────────┘
         │ 2. Conduct interview
         │    - Record video
         │    - Detect emotions
         │    - Generate transcript
         ▼
┌─────────────────┐
│ Gemini Live     │
│ + Emotion API   │
└────────┬────────┘
         │ 3. Interview ends
         ▼
┌─────────────────────┐
│ geminiService.      │──► Analyze interview
│ analyzeInterview()  │
└────────┬────────────┘
         │ Returns: { confidence, knowledge,
         │           communication, emotion... }
         ▼
┌──────────────────┐
│ Upload video to  │
│ Storage          │
└────────┬─────────┘
         │
         ▼
┌────────────────────┐
│ supabase.from(     │
│ 'video_interviews' │
│ ).insert({...})    │
└────────┬───────────┘
         │
         ▼
┌────────────────────┐
│ supabase.from(     │
│'interview_analysis'│
│ ).insert({         │
│   scores,          │
│   strengths,       │
│   emotions...      │
│ })                 │
└────────────────────┘
         │
         ▼
┌────────────────────┐
│ Update candidate   │
│ status to          │
│'INTERVIEW_COMPLETED'│
└────────────────────┘
```

---

## 📊 Database Schema Relationships

```
┌─────────────────┐
│      jobs       │
│─────────────────│
│ id (PK)         │◄──────┐
│ title           │       │
│ department      │       │
│ description     │       │
│ status          │       │
│ created_at      │       │
└─────────────────┘       │
                          │ job_id (FK)
                          │
┌─────────────────────────┼─────────────────┐
│      candidates         │                 │
│─────────────────────────┼─────────────────│
│ id (PK)                 │                 │◄─────────┐
│ job_id (FK) ────────────┘                 │          │
│ name                                      │          │
│ email                                     │          │
│ resume_text                               │          │
│ resume_file_url                           │          │
│ status                                    │          │
└───────────────────────────────────────────┘          │
                     │                                 │
                     │ candidate_id (FK)               │
       ┌─────────────┼──────────────┬──────────────────┼────────┐
       │             │              │                  │        │
       ▼             ▼              ▼                  ▼        ▼
┌──────────────┐ ┌──────────┐ ┌──────────┐ ┌───────────────┐ ┌────────────┐
│resume_analysis│ │call_    │ │video_    │ │interview_     │ │  (more)    │
│              │ │sessions  │ │interviews│ │analysis       │ │            │
│──────────────│ │──────────│ │──────────│ │───────────────│ │────────────│
│id (PK)       │ │id (PK)   │ │id (PK)   │ │id (PK)        │ │            │
│candidate_id  │ │candidate │ │candidate │ │video_interview│ │            │
│score         │ │_id (FK)  │ │_id (FK)  │ │_id (FK)       │ │            │
│ranking       │ │audio_url │ │video_url │ │candidate_id   │ │            │
│strengths     │ │transcript│ │transcript│ │_id (FK) ──────┘ │            │
│weaknesses    │ │summary   │ │emotions  │ │scores...      │ │            │
└──────────────┘ └──────────┘ └──────────┘ └───────────────┘ └────────────┘
```

---

## 🔐 Security Architecture

```
┌─────────────────────────────────────────────┐
│          CLIENT (Browser)                   │
├─────────────────────────────────────────────┤
│                                             │
│  .env file (local only)                     │
│  ├─ VITE_SUPABASE_URL                      │
│  ├─ VITE_SUPABASE_ANON_KEY (public)        │
│  └─ VITE_GEMINI_API_KEY (should be server) │
│                                             │
└──────────────┬──────────────────────────────┘
               │ HTTPS
               ▼
┌─────────────────────────────────────────────┐
│         SUPABASE BACKEND                    │
├─────────────────────────────────────────────┤
│                                             │
│  Row Level Security (RLS)                   │
│  ├─ Current: Allow all (dev mode)           │
│  └─ Production: Add auth checks             │
│                                             │
│  Storage Policies                           │
│  ├─ Current: Public buckets                 │
│  └─ Production: Authenticated only          │
│                                             │
└─────────────────────────────────────────────┘
```

### 🔒 Production Security Checklist

```
Current State (Dev):
┌──────────────────────────────────┐
│ ⚠️  No authentication required   │
│ ⚠️  Open RLS policies            │
│ ⚠️  Public storage buckets       │
│ ⚠️  Client-side API keys         │
└──────────────────────────────────┘

Production Requirements:
┌──────────────────────────────────┐
│ ✅ Supabase Auth enabled         │
│ ✅ RLS by user/role              │
│ ✅ Private buckets               │
│ ✅ Server-side API keys          │
│ ✅ Input validation              │
│ ✅ Rate limiting                 │
└──────────────────────────────────┘
```

---

## 📦 Component Dependency Graph

```
App.tsx
  │
  ├─► JobList.tsx
  │     │
  │     └─► supabaseService.ts
  │           ├─► supabase.ts (client)
  │           └─► types/
  │
  ├─► CandidateList.tsx
  │     │
  │     ├─► supabaseService.ts
  │     ├─► geminiService.ts
  │     └─► pdfParser.ts
  │
  └─► CandidateDetail.tsx
        │
        └─► supabaseService.ts
```

---

## 🔌 Integration Points Map

```
┌─────────────────────────────────────────────────────────┐
│                   EXISTING APPS                         │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  gemini-hr-co-pilot (3)/                               │
│  ├─ Resume analysis ────────► ✅ INTEGRATED            │
│  ├─ PDF parsing     ────────► ✅ INTEGRATED            │
│  └─ Candidate ranking ──────► ✅ INTEGRATED            │
│                                                         │
│  gemini-ai-interview-scheduler-with-dual-recording/     │
│  ├─ Call components ────────► 🔌 READY TO INTEGRATE   │
│  ├─ LiveAPI session ────────► 🔌 Hook: saveCallSession()│
│  └─ Audio recording ────────► 🔌 Storage ready         │
│                                                         │
│  ai-technical-interviewer/                              │
│  ├─ Interview components ───► 🔌 READY TO INTEGRATE   │
│  ├─ Video recording ────────► 🔌 Hook: saveVideoInterview()│
│  ├─ Emotion detection ──────► 🔌 Storage ready         │
│  └─ Analysis ───────────────► 🔌 Hook: saveInterviewAnalysis()│
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 💾 Storage Architecture

```
Supabase Storage
│
├── resumes/
│   └── {job_id}/
│       ├── {timestamp}_resume1.pdf
│       ├── {timestamp}_resume2.pdf
│       └── ...
│
├── call-recordings/
│   └── {candidate_id}/
│       ├── {timestamp}_call_recording.webm
│       └── ...
│
└── video-interviews/
    └── {candidate_id}/
        ├── {timestamp}_interview.webm
        └── ...

File Naming Pattern:
{timestamp}_{description}.{ext}

Example:
1699123456789_call_recording.webm
1699234567890_interview.webm
```

---

## 🎯 State Management

```
┌─────────────────────────────────────────┐
│         App-Level State                 │
│         (useState in App.tsx)           │
├─────────────────────────────────────────┤
│                                         │
│  • jobs: Job[]                          │
│  • selectedJobId: string | null         │
│  • selectedCandidateId: string | null   │
│  • loading: boolean                     │
│                                         │
└─────────────────────────────────────────┘
            │
            ├──► JobList (props)
            │     • jobs
            │     • selectedJobId
            │     • onSelectJob()
            │     • onJobCreated()
            │
            ├──► CandidateList (props)
            │     • jobId
            │     • onViewCandidate()
            │
            └──► CandidateDetail (props)
                  • candidateId
                  • onBack()

Future: Consider React Query for caching
```

---

## 🚀 Deployment Architecture

```
Development:
┌──────────────┐
│ localhost    │
│ :5173        │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Vite Dev     │
│ Server       │
└──────────────┘

Production:
┌──────────────┐
│ Vercel/      │
│ Netlify CDN  │
└──────┬───────┘
       │
       ├─► Static Files (HTML/JS/CSS)
       │
       └─► API Requests
             │
             ▼
       ┌──────────────┐
       │  Supabase    │
       │  (Backend)   │
       └──────────────┘
```

---

## 📈 Scalability Considerations

```
Current Setup:
├─ Single database
├─ Direct Supabase calls
└─ Client-side processing

Future Optimizations:
├─ Add Redis caching
├─ Implement pagination
├─ Use React Query
├─ Lazy load components
├─ Add worker threads for PDF parsing
└─ Implement batch operations
```

---

## 🧪 Testing Architecture (Future)

```
Unit Tests:
├─ services/
│   ├─ supabaseService.test.ts
│   └─ geminiService.test.ts
│
Integration Tests:
├─ components/
│   ├─ JobList.test.tsx
│   ├─ CandidateList.test.tsx
│   └─ CandidateDetail.test.tsx
│
E2E Tests:
└─ flows/
    ├─ job-creation.spec.ts
    ├─ candidate-addition.spec.ts
    └─ full-workflow.spec.ts
```

---

This architecture provides a solid foundation for a scalable, maintainable HR recruitment platform with clear separation of concerns and integration points for future enhancements.
